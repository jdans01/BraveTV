# BraveTV Browser 🦁📺

Navegador para Android TV con bloqueador de anuncios integrado.  
Bloquea anuncios de YouTube, Google Ads, trackers y más.

## Funciones
- ✅ Bloqueo de anuncios de YouTube (pre-roll, mid-roll, banners)
- ✅ Skip automático de anuncios que logran pasar
- ✅ Interfaz optimizada para control remoto
- ✅ Compatible con Hisense, TCL, Sony, Philips y cualquier Android TV
- ✅ Requiere Android 5.0+ (API 21)
- ✅ User-Agent Smart TV para cargar YouTube TV correctamente

---

## Cómo compilar el APK

### Opción 1 — Android Studio (recomendado, gratis)

1. Descarga Android Studio: https://developer.android.com/studio
2. Abre esta carpeta como proyecto
3. Espera que sincronice Gradle
4. Menú **Build → Build APK(s)**
5. El APK queda en: `app/build/outputs/apk/debug/app-debug.apk`

### Opción 2 — Compilar online GRATIS con GitHub Actions

1. Sube esta carpeta a un repositorio GitHub
2. Crea el archivo `.github/workflows/build.yml` con este contenido:

```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          java-version: '17'
          distribution: 'temurin'
      - name: Build APK
        run: ./gradlew assembleDebug
      - uses: actions/upload-artifact@v3
        with:
          name: BraveTV-APK
          path: app/build/outputs/apk/debug/app-debug.apk
```

3. GitHub compilará el APK y lo podrás descargar en la pestaña **Actions → Artifacts**

### Opción 3 — Compilar con línea de comandos

```bash
# En macOS/Linux/Windows con Android Studio instalado:
./gradlew assembleDebug
```

---

## Instalar en tu Hisense Android TV 12

1. Copia el APK a un USB
2. En tu TV: **Ajustes → Preferencias del dispositivo → Seguridad → Fuentes desconocidas → ON**
3. Instala un file manager (FX File Explorer desde Play Store)
4. Abre el APK desde el USB con FX File Explorer
5. ¡Listo!

---

## Estructura del proyecto

```
BraveTVBrowser/
├── app/src/main/
│   ├── AndroidManifest.xml
│   ├── java/com/bravetv/browser/
│   │   └── MainActivity.java      ← Lógica principal + ad blocker
│   └── res/
│       ├── layout/activity_main.xml
│       ├── values/strings.xml
│       ├── values/styles.xml
│       └── drawable/              ← Botones y estilos TV
├── build.gradle
├── settings.gradle
└── gradle.properties
```
